import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import Link from '@mui/material/Link';
import IconButton from '@mui/material/IconButton';

import FacebookIcon from '@mui/icons-material/Facebook';
import InstagramIcon from '@mui/icons-material/Instagram';
import XIcon from '@mui/icons-material/X';
import YouTubeIcon from '@mui/icons-material/YouTube';


const FooterLink = ({ children }) => (
  <Link
    href="#"
    underline="none"
    sx={{
      display: 'block',
      fontSize: '15px',
      color: '#000',
      mb: 0.8,
      '&:hover': {
        textDecoration: 'underline',
      },
    }}
  >
    {children}
  </Link>
);


export default function Footer() {
  return (
    <Box sx={{ backgroundColor: '#fff', borderTop: '1px solid #eee', mt: 12 }}>
      <Container maxWidth={false}  sx={{ px: { xs: 2, md: 9 },}}>
        <Grid container sx={{py: 7,display: 'flex',justifyContent: 'space-between',}}>

         {/* 1 COLUMN 1 */}
          <Grid item xs={12} sm={6} md={3}>
            <Typography sx={{fontSize: '17px', fontWeight: 600, mb: 2,}} gutterBottom>
              Help & Support
            </Typography>
            <FooterLink display="block">Customer Service</FooterLink>
            <FooterLink display="block">Order Status</FooterLink>
            <FooterLink display="block">Shipping</FooterLink>
            <FooterLink display="block">Returns</FooterLink>
          </Grid>

          {/* COLUMN 2 */}
          <Grid item xs={12} sm={6} md={3}>
            <Typography sx={{fontSize: '17px', fontWeight: 600, mb: 2,}} gutterBottom>
              About Us
            </Typography>
            <FooterLink display="block">Our Story</FooterLink>
            <FooterLink display="block">Sustainability</FooterLink>
            <FooterLink display="block">Careers</FooterLink>
            <FooterLink display="block">Press</FooterLink>
          </Grid>

          {/* COLUMN 3 */}
          <Grid item xs={12} sm={6} md={3}>
            <Typography sx={{fontSize: '17px', fontWeight: 600, mb: 2,}} gutterBottom>
              Join Us
            </Typography>
            <FooterLink display="block">Newsletter</FooterLink>
            <FooterLink display="block">Affiliate Program</FooterLink>
            <FooterLink display="block">The Club</FooterLink>
          </Grid>

          {/* COLUMN 4 – SOCIAL */}
          <Grid item xs={12} sm={6} md={3}>
            <Typography sx={{fontSize: '17px', fontWeight: 600, mb: 2,}} gutterBottom>
              Follow Us
            </Typography>

            <IconButton><XIcon /></IconButton>
            <IconButton><FacebookIcon /></IconButton>
            <IconButton><InstagramIcon /></IconButton>
            <IconButton><YouTubeIcon /></IconButton>
          </Grid>

        </Grid>

        {/* BOTTOM LINE */}
        <Box sx={{ borderTop: '1px solid #eee', py: 2 }}>
          <Typography variant="body2" color="text.secondary">
            © 2025 Your Brand Name. All rights reserved.
          </Typography>
        </Box>
      </Container>
    </Box>
  );
}
