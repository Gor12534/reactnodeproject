import { Box, Typography, Grid } from '@mui/material';
import img1 from '../../../assets/images/download.jpg';
const items = [
  { id: 1, img: img1, title: 'Plaid Shirt' },
  { id: 2, img: img1, title: 'Colorblock Sweater' },
];

export default function CompleteTheLook() {
  return (
    <Box sx={{ mt: 6 }}>
      <Typography variant="h6" mb={3}>
        Complete The Look
      </Typography>

      <Grid container spacing={3}>
        {items.map((item) => (
          <Grid item xs={6} key={item.id}>
            <img
              src={item.img}
              alt={item.title}
              style={{ width: '100%' }}
            />
            <Typography fontSize={14} mt={1}>
              {item.title}
            </Typography>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}
