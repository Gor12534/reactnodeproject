import {
  Box,
  Typography,
  Rating,
  Stack,
  Button,
  Divider,
} from '@mui/material';

import ProductAccordion from '../ProductAccordion/ProductAccordion';
import CompleteTheLook from '../Lookslike/Lookslike';
const colors = [
  '#111827',
  '#9CA3AF',
  '#000000',
  '#E5E7EB',
  '#4B5563',
  '#93C5FD',
];

const sizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];





export default function ProductInfo() {
  return (
    <Box>

      {/* Breadcrumb */}
      <Typography fontSize={12} color="text.secondary" mb={1}>
        Men / Clothing / Tops & Sweaters
      </Typography>

      {/* Title */}
      <Typography variant="h5" fontWeight={500} mb={1}>
        Classic Quarter-Zip Sweater
      </Typography>

      {/* Rating */}
      <Box display="flex" alignItems="center" mb={2}>
        <Rating value={4.8} precision={0.1} readOnly />
        <Typography fontSize={13} ml={1}>
          (310)
        </Typography>
      </Box>

      {/* Price */}
      <Box display="flex" alignItems="center" gap={1} mb={3}>
        <Typography sx={{ textDecoration: 'line-through', color: '#6B7280' }}>
          $89.50
        </Typography>
        <Typography fontWeight={600}>
          $53.70
        </Typography>
        <Typography color="error">
          40% off
        </Typography>
      </Box>

      {/* Color */}
      <Typography fontSize={14} fontWeight={500} mb={1}>
        Color <span style={{ fontWeight: 400 }}>Grey Heather</span>
      </Typography>

      <Stack direction="row" spacing={1} mb={3}>
        {colors.map((color, index) => (
          <Box
            key={index}
            sx={{
              width: 26,
              height: 26,
              borderRadius: '50%',
              bgcolor: color,
              border: '1px solid #D1D5DB',
              cursor: 'pointer',
            }}
          />
        ))}
      </Stack>

      {/* Size */}
      <Box display="flex" justifyContent="space-between" mb={1}>
        <Typography fontSize={14} fontWeight={500}>
          Size
        </Typography>
        <Typography fontSize={13} sx={{ cursor: 'pointer' }}>
          Find My Size
        </Typography>
      </Box>

      <Stack direction="row" spacing={1} mb={3} flexWrap="wrap">
        {sizes.map((size) => (
          <Button
            key={size}
            variant="outlined"
            sx={{
              minWidth: 48,
              borderRadius: 0,
              color: '#111827',
              borderColor: '#D1D5DB',
            }}
          >
            {size}
          </Button>
        ))}
      </Stack>

      {/* Add to Cart */}
      <Button
        fullWidth
        size="large"
        sx={{
          bgcolor: '#000',
          color: '#fff',
          borderRadius: 0,
          mb: 2,
          '&:hover': { bgcolor: '#111' },
        }}
      >
        Select a Size
      </Button>

      <Divider sx={{ my: 3 }} />

      {/* Shipping */}
      <Typography fontSize={14} mb={1}>
        Free Standard Shipping on Orders $100+
      </Typography>

      <Typography fontSize={14}>
        4 payments of $13.43 with <b>Klarna</b> or <b>Afterpay</b>
      </Typography>



         {/* SECOND SCREENSHOT PART 👇 */}
      <ProductAccordion />

      <CompleteTheLook />

      
    </Box>
  );
}
