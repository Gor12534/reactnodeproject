
import img11 from '../../../assets/images/download.jpg'
import { Box, Stack } from '@mui/material';

const images = [
  img11,
  img11,
  img11
];

export default function ProductImages() {
  return (
    <Stack spacing={3}>
      {images.map((img, index) => (
        <Box key={index}>
          <img
            src={img}
            alt="Product"
            style={{
              width: '100%',
              objectFit: 'cover',
            }}
          />
        </Box>
      ))}
    </Stack>
  );
}
