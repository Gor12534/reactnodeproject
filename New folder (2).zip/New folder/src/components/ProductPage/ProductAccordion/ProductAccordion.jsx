import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
  Rating,
  Box
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

export default function ProductAccordion() {
  return (
    <Box sx={{ mt: 4 }}>

      <Accordion elevation={0}>
        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
          <Typography fontWeight={500}>Product Details</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography fontSize={14}>
            Classic quarter-zip sweater crafted from soft cotton blend.
            Features ribbed cuffs and signature logo.
          </Typography>
        </AccordionDetails>
      </Accordion>

      <Accordion elevation={0}>
        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
          <Typography fontWeight={500}>Shipping & Returns</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography fontSize={14}>
            Free standard shipping on orders over $100.  
            Free returns within 30 days.
          </Typography>
        </AccordionDetails>
      </Accordion>

      <Accordion elevation={0}>
        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
          <Box display="flex" alignItems="center" gap={1}>
            <Typography fontWeight={500}>Reviews (310)</Typography>
            <Rating value={4.8} precision={0.1} readOnly size="small" />
            <Typography fontSize={14}>4.8 / 5</Typography>
          </Box>
        </AccordionSummary>
        <AccordionDetails>
          <Typography fontSize={14}>
            ⭐⭐⭐⭐⭐  
            Customers love the fit, quality, and comfort.
          </Typography>
        </AccordionDetails>
      </Accordion>

      <Accordion elevation={0}>
        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
          <Typography fontWeight={500}>
            Questions & Answers (64)
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography fontSize={14}>
            Q: Is this sweater true to size?  
            A: Yes, it fits true to size.
          </Typography>
        </AccordionDetails>
      </Accordion>

    </Box>
  );
}
