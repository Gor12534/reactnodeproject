// src/components/ShippingForm.js
import React from 'react';
import { TextField, Button, Box, FormControlLabel, Checkbox, Typography } from '@mui/material';

const ShippingTo = () => {
  return (
    <Box sx={{ width: '100%' }}>
      <Typography variant="h6" gutterBottom>Shipping To</Typography>
      
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {/* First & Last Name Row */}
        <Box sx={{ display: 'flex', gap: 2, flexDirection: { xs: 'column', sm: 'row' } }}>
          <TextField fullWidth label="First Name" variant="outlined" required />
          <TextField fullWidth label="Last Name" variant="outlined" required />
        </Box>

        {/* Address Fields */}
        <TextField fullWidth label="Address" variant="outlined" required />
        <TextField fullWidth label="Apartment, Suite, Etc. (Optional)" variant="outlined" />

        {/* City, State, Zip Row */}
        <Box sx={{ display: 'flex', gap: 2, flexDirection: { xs: 'column', sm: 'row' } }}>
          <TextField fullWidth label="City" variant="outlined" required />
          <TextField fullWidth label="State" variant="outlined" required />
          <TextField fullWidth label="Zip Code" variant="outlined" required />
        </Box>

      </Box>
    </Box>
  );
};

export default ShippingTo;