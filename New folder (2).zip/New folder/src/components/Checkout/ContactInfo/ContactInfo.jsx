// src/components/ContactInformation.js
import React from 'react';
import { TextField, Grid ,Box,Typography,FormControlLabel,Checkbox,Button} from '@mui/material';

const ContactInfo = () => {
  return (
 <Grid 
  container 
  spacing={2} 
  sx={{ 
    width: '100%', 
    m: 0,
    display: 'flex',
    flexWrap: 'wrap' // Explicitly tell the container to wrap
  }}
>
  {/* Row 1: These two add up to 12, so they fill the first row perfectly */}
  <Grid item xs={12} sm={6}>
    <TextField fullWidth label="Email" variant="outlined" required />
  </Grid>

  <Grid item xs={12} sm={6}>
    <TextField fullWidth label="Phone Number" variant="outlined" required />
  </Grid>

  {/* Row 2: This is 12, so it MUST start on a new line because there is 0 space left above */}
  <Grid item xs={12} sm={12}> 
    <Box sx={{ display: 'flex', flexDirection: 'column', mt: 1 }}>
      <FormControlLabel
        control={<Checkbox />}
        label="I would like to receive updates and promotions via email."
      />
      <Button fullWidth variant="contained" color="primary" sx={{ alignSelf: 'flex-start', minWidth: '200px' }}>
        Save
      </Button>
    </Box>
  </Grid>
</Grid>
  );
};

export default ContactInfo;
