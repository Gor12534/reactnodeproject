// src/components/ShoppingBag.js
import React from 'react';
import { Box, Paper, Typography, Button, Grid, Divider } from '@mui/material';

const ShoppingBag = ({ cartItems }) => {
  return (
    <Paper elevation={3} sx={{ padding: 2 }}>
      <Typography variant="h6" gutterBottom>In Your Shopping Bag</Typography>
      <Divider sx={{ my: 2 }} />
      {cartItems.map((item) => (
        <Box key={item.id} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
          <Box display="flex" alignItems="center">
            <img src={item.imageUrl} alt={item.name} width="60" />
            <Box ml={2}>
              <Typography variant="body1">{item.name}</Typography>
              <Typography variant="body2">{item.size} | {item.color}</Typography>
              <Typography variant="body2" color="textSecondary">Qty: {item.quantity}</Typography>
            </Box>
          </Box>
          <Typography variant="body1">${(item.discountedPrice * item.quantity).toFixed(2)}</Typography>
          <Button variant="outlined" color="secondary" size="small">Remove</Button>
        </Box>
      ))}
    </Paper>
  );
};

export default ShoppingBag;
