import { Box, Typography, List, ListItemButton } from '@mui/material';
import { NavLink } from 'react-router-dom';

const links = [
  { label: 'Profile', path: '/account/profile' },
  { label: 'Orders', path: '/account/orders' },
  { label: 'Addresses', path: '/account/addresses' },
  { label: 'Security', path: '/account/security' },
];

export default function AccountSidebar() {
  return (
    <Box sx={{ width: 220 }}>
      <Typography fontWeight={600} mb={2}>
        My Account
      </Typography>

      <List>
        {links.map(link => (
          <ListItemButton
            key={link.path}
            component={NavLink}
            to={link.path}
            sx={{
              '&.active': {
                fontWeight: 600,
                backgroundColor: '#f5f5f5',
              },
            }}
          >
            {link.label}
          </ListItemButton>
        ))}
      </List>
    </Box>
  );
}
