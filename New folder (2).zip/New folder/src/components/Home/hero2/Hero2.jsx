import './hero2.css';

import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';

export default function HeroBanner() {
  return (
    <div
      className="hero"
      style={{
        backgroundImage:
          "url('https://images.unsplash.com/photo-1521334884684-d80222895322')",
      }}
    >
      <div className="hero-overlay" />

      <Container maxWidth="xl" className="hero-content">
        <Stack spacing={3} sx={{ maxWidth: 500 }}>
          <Typography variant="h2" sx={{ fontWeight: 600 }}>
            New Season Styles
          </Typography>

          <Typography sx={{ fontSize: '16px', opacity: 0.9 }}>
            Discover timeless essentials designed for everyday wear.
          </Typography>

          <Button
            variant="outlined"
            sx={{
              color: '#fff',
              borderColor: '#fff',
              width: 'fit-content',
              '&:hover': {
                backgroundColor: '#fff',
                color: '#000',
              },
            }}
          >
            Shop Now
          </Button>
        </Stack>
      </Container>
    </div>
  );
}
