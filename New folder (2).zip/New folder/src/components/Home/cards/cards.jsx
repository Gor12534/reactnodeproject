import React from 'react';
import { Container, Grid, Box, Typography, Link } from '@mui/material';
import './cards.css';
import img1 from '../../../assets/images/download.jpg';
import img2 from './download.jpg';


const items = [
  {
    title: 'The Logo Shop',
    linkText: 'Shop Now',
    image: img1,
  },
  {
    title: 'The Cable Knit Shop',
    linkText: 'Shop Now',
    image: img1,
  },
  {
    title: 'Shoes & Accessories',
    linkText: 'Shop Now',
    image: img1,
  },
  {
    title: 'Tommy Stories',
    linkText: 'Learn More',
    image: img2,
  },
];

function FeaturedCards() {
  return (
    <Box className="featuredSection">
      <Container maxWidth="xl">
        <Grid container spacing={3}>
          {items.map((item, index) => (
            <Grid item xs={12} sm={6} md={3} key={index}>
              <Box className="featuredItem">
                <img src={item.image} alt={item.title} />
                <Typography className="featuredTitle">
                  {item.title}
                </Typography>
                <Link className="featuredLink" href="#">
                  {item.linkText}
                </Link>
              </Box>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
}

export default FeaturedCards;
