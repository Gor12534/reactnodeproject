import React from 'react';
import {
  Container,
  Grid,
  Typography,
  TextField,
  Button,
  Checkbox,
  FormControlLabel,
  Box
} from '@mui/material';

import './joinbanner.css';

function JoinBanner() {
  return (
    <Box className="joinClub">
      <Container maxWidth="lg">
        <Grid container spacing={6} alignItems="center">

          {/* LEFT */}
          <Grid item xs={12} md={5}>
            <Typography className="joinTitleSmall">
              JOIN
            </Typography>
            <Typography className="joinTitleBig">
              the hilfiger club
            </Typography>
          </Grid>

          {/* RIGHT */}
          <Grid item xs={12} md={7}>
            <Typography className="joinText">
              Enter your email for <strong>20% off</strong> your next order and more VIP perks
            </Typography>

            <Typography className="joinTextSmall">
              Or text JOIN to TOMMY (86669) to sign up instantly
            </Typography>

            <Box className="joinForm">
              <TextField
                placeholder="Your email"
                variant="outlined"
                fullWidth
              />
              <Button variant="contained" className="joinButton">
                Join Now
              </Button>
            </Box>

            <FormControlLabel
              control={<Checkbox />}
              label={
                <Typography className="joinDisclaimer">
                  By clicking the Join Now button, I agree to the Terms and Conditions and Privacy Policy.
                </Typography>
              }
            />
          </Grid>

        </Grid>
      </Container>
    </Box>
  );
}

export default JoinBanner;
