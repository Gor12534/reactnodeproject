// src/components/Sustainability.js
import React from 'react';
import { Box, Typography, Paper } from '@mui/material';

const Sustainability = () => {
  return (
    <Paper sx={{ padding: 4, marginBottom: 4 }}>
      <Typography variant="h4" gutterBottom>
        Sustainability
      </Typography>
      <Typography variant="body1">
        We are committed to making fashion that doesn’t cost the earth. Sustainability is at the heart of everything we do. From using eco-friendly materials to implementing fair labor practices, we are dedicated to creating a better future for the fashion industry and the planet.
      </Typography>
    </Paper>
  );
};

export default Sustainability;
