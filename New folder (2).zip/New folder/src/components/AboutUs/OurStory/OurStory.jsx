// src/components/OurStory.js
import React from 'react';
import { Box, Typography, Paper } from '@mui/material';

const OurStory = () => {
  return (
    <Paper sx={{ padding: 4, marginBottom: 4 }}>
      <Typography variant="h4" gutterBottom>
        Our Story
      </Typography>
      <Typography variant="body1">
        Our story is one of passion, craftsmanship, and a relentless commitment to quality. We began with a simple idea: to create timeless clothing that blends classic design with modern comfort. Over the years, we have expanded our offerings while staying true to our roots—offering high-quality, stylish clothing for those who value both aesthetics and practicality.
      </Typography>
    </Paper>
  );
};

export default OurStory;
