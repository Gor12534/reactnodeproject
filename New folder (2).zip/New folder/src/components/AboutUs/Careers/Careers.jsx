// src/components/Careers.js
import React from 'react';
import { Box, Typography, Paper } from '@mui/material';

const Careers = () => {
  return (
    <Paper sx={{ padding: 4, marginBottom: 4 }}>
      <Typography variant="h4" gutterBottom>
        Careers
      </Typography>
      <Typography variant="body1">
        Join our passionate team of innovators, designers, and creators! At [Brand], we believe in fostering a culture of collaboration and growth. If you're interested in shaping the future of fashion and making a difference, explore our open positions and start your career with us today.
      </Typography>
    </Paper>
  );
};

export default Careers;
