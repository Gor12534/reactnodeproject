// src/components/Press.js
import React from 'react';
import { Box, Typography, Paper } from '@mui/material';

const Press = () => {
  return (
    <Paper sx={{ padding: 4, marginBottom: 4 }}>
      <Typography variant="h4" gutterBottom>
        Press
      </Typography>
      <Typography variant="body1">
        Our brand has been featured in various leading publications. From magazine interviews to runway shows, our commitment to quality and innovation has garnered attention from top influencers and fashion experts. Explore our press coverage and see why we are a standout name in the industry.
      </Typography>
    </Paper>
  );
};

export default Press;
