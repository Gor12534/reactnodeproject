import {
  Box,
  Button,
  TextField,
  Checkbox,
  FormControlLabel,
  Typography,
} from '@mui/material';

export default function RegisterForm() {
  return (
    <Box component="form">
      <TextField
        fullWidth
        label="First Name"
        margin="normal"
      />

      <TextField
        fullWidth
        label="Last Name"
        margin="normal"
      />

      <TextField
        fullWidth
        label="Email"
        type="email"
        margin="normal"
      />

      <TextField
        fullWidth
        label="Password"
        type="password"
        margin="normal"
      />

      <Box sx={{ mt: 2 }}>
        <FormControlLabel
          control={<Checkbox />}
          label="I would like to receive updates and promotions"
        />

        <FormControlLabel
          control={<Checkbox required />}
          label={
            <Typography variant="body2">
              I agree to the <b>Terms & Conditions</b> and <b>Privacy Policy</b>
            </Typography>
          }
        />
      </Box>

      <Button
        fullWidth
        variant="contained"
        sx={{
          mt: 4,
          py: 1.5,
          backgroundColor: '#000',
          borderRadius: 0,
          '&:hover': { backgroundColor: '#000' },
        }}
      >
        Create Account
      </Button>
    </Box>
  );
}
