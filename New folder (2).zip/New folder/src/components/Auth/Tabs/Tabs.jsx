import { Box, Button } from '@mui/material';

export default function AuthTabs({ mode, setMode }) {
  return (
    <Box sx={{ display: 'flex', mb: 4 }}>
      <Button
        fullWidth
        onClick={() => setMode('login')}
        sx={{
          borderBottom: mode === 'login' ? '2px solid black' : '1px solid #ccc',
          borderRadius: 0,
          fontWeight: 600,
        }}
      >
        Sign In
      </Button>

      <Button
        fullWidth
        onClick={() => setMode('signup')}
        sx={{
          borderBottom: mode === 'signup' ? '2px solid black' : '1px solid #ccc',
          borderRadius: 0,
          fontWeight: 600,
        }}
      >
        Sign Up
      </Button>
    </Box>
  );
}
