import {
  Box,
  Button,
  TextField,
  Typography,
  Divider,
} from '@mui/material';

export default function LoginForm() {
  return (
    <Box component="form">
      <TextField
        fullWidth
        label="Email"
        type="email"
        margin="normal"
      />

      <TextField
        fullWidth
        label="Password"
        type="password"
        margin="normal"
      />

      <Button
        fullWidth
        variant="contained"
        sx={{
          mt: 4,
          py: 1.5,
          backgroundColor: '#000',
          borderRadius: 0,
          '&:hover': { backgroundColor: '#000' },
        }}
      >
        Sign In
      </Button>

      <Divider sx={{ my: 3 }} />

      <Typography variant="body2" align="center">
        Forgot your password?
      </Typography>
    </Box>
  );
}
