// src/components/ProductCard.js
import React from 'react';
import { Paper, Box, Typography, Button } from '@mui/material';

const ProductCard = ({ product }) => {
  return (
    <Paper elevation={3} sx={{ padding: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <Box display="flex" alignItems="center">
        <img src={product.imageUrl} alt={product.name} width="100" />
        <Box ml={2}>
          <Typography variant="h6">{product.name}</Typography>
          <Typography variant="body2">{product.color} | Size: {product.size}</Typography>
          <Typography variant="body1" color="textSecondary">
            ${product.discountedPrice.toFixed(2)} <s>${product.originalPrice.toFixed(2)}</s>
          </Typography>
        </Box>
      </Box>
      <Box>
        <Button variant="outlined" color="primary">Remove</Button>
      </Box>
    </Paper>
  );
};

export default ProductCard;
