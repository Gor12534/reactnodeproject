// src/components/OrderSummary.js
import React from 'react';
import { Paper, Typography, Divider, Box, Button } from '@mui/material';

const OrderSummary = ({ subtotal }) => {
  return (
    <Paper elevation={3} sx={{ padding: 2 }}>
      <Typography variant="h6">Order Summary</Typography>
      <Divider sx={{ my: 2 }} />
      <Typography variant="body1">Subtotal: ${subtotal.toFixed(2)}</Typography>
      <Typography variant="body1">Shipping: Free</Typography>
      <Typography variant="body1">Tax: Calculated at checkout</Typography>
      <Divider sx={{ my: 2 }} />
      <Typography variant="h6">Total: ${subtotal.toFixed(2)}</Typography>
      <Box mt={2}>
        <Button fullWidth variant="contained" color="primary">
          Start Checkout
        </Button>
      </Box>
      <Box mt={2} display="flex" justifyContent="space-around">
        <Button variant="outlined" color="secondary" fullWidth>
          PayPal
        </Button>
        <Button variant="outlined" color="secondary" fullWidth>
          Klarna
        </Button>
      </Box>
    </Paper>
  );
};

export default OrderSummary;
