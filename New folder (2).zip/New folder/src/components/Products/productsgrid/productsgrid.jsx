import { Grid, Container } from '@mui/material';
import ProductCard from '../productcard/productcard';
import img1 from '../../../assets/images/download.jpg';
const products = [
  {
    id: 1,
    title: 'Classic Crewneck Sweater',
    image: img1,
    oldPrice: 79.5,
    price: 47.7,
    discount: 40,
    colors: ['#111827', '#6B7280', '#7C2D12'],
    rating: 4.5,
    reviews: 183,
  },
  {
    id: 2,
    title: 'Regular Fit Mini Plaid Shirt',
    image: img1,
    oldPrice: 89.5,
    price: 53.7,
    discount: 40,
    colors: ['#991B1B', '#1F2933'],
    rating: 4.2,
    reviews: 95,
  },
  {
    id: 3,
    title: 'Slim Fit Stretch Pique Polo',
    image: img1,
    oldPrice: 69.5,
    price: 28.99,
    discount: 58,
    colors: ['#7C2D12', '#1E3A8A', '#111827'],
    rating: 4.7,
    reviews: 127,
  },
  {
    id: 4,
    title: 'THFlex Tommy Straight Chino',
    image: img1,
    oldPrice: 89.5,
    price: 53.7,
    discount: 40,
    colors: ['#111827', '#9CA3AF', '#92400E'],
    rating: 4.6,
    reviews: 125,
  },
   {
    id: 1,
    title: 'Classic Crewneck Sweater',
    image: img1,
    oldPrice: 79.5,
    price: 47.7,
    discount: 40,
    colors: ['#111827', '#6B7280', '#7C2D12'],
    rating: 4.5,
    reviews: 183,
  },
  {
    id: 2,
    title: 'Regular Fit Mini Plaid Shirt',
    image: img1,
    oldPrice: 89.5,
    price: 53.7,
    discount: 40,
    colors: ['#991B1B', '#1F2933'],
    rating: 4.2,
    reviews: 95,
  },
  {
    id: 3,
    title: 'Slim Fit Stretch Pique Polo',
    image: img1,
    oldPrice: 69.5,
    price: 28.99,
    discount: 58,
    colors: ['#7C2D12', '#1E3A8A', '#111827'],
    rating: 4.7,
    reviews: 127,
  },
  {
    id: 4,
    title: 'THFlex Tommy Straight Chino',
    image: img1,
    oldPrice: 89.5,
    price: 53.7,
    discount: 40,
    colors: ['#111827', '#9CA3AF', '#92400E'],
    rating: 4.6,
    reviews: 125,
  },
   {
    id: 1,
    title: 'Classic Crewneck Sweater',
    image: img1,
    oldPrice: 79.5,
    price: 47.7,
    discount: 40,
    colors: ['#111827', '#6B7280', '#7C2D12'],
    rating: 4.5,
    reviews: 183,
  },
  {
    id: 2,
    title: 'Regular Fit Mini Plaid Shirt',
    image: img1,
    oldPrice: 89.5,
    price: 53.7,
    discount: 40,
    colors: ['#991B1B', '#1F2933'],
    rating: 4.2,
    reviews: 95,
  },
  {
    id: 3,
    title: 'Slim Fit Stretch Pique Polo',
    image: img1,
    oldPrice: 69.5,
    price: 28.99,
    discount: 58,
    colors: ['#7C2D12', '#1E3A8A', '#111827'],
    rating: 4.7,
    reviews: 127,
  },
  {
    id: 4,
    title: 'THFlex Tommy Straight Chino',
    image: img1,
    oldPrice: 89.5,
    price: 53.7,
    discount: 40,
    colors: ['#111827', '#9CA3AF', '#92400E'],
    rating: 4.6,
    reviews: 125,
  },
];

export default function ProductsGrid() {
  return (
    <Container maxWidth="xl" sx={{ mt: 4 }}>
      <Grid container spacing={3}>
        {products.map((product) => (
          <Grid item xs={6} sm={4} md={3} key={product.id}>
            <ProductCard product={product} />
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}
