import React from 'react';
import {
  Box,
  Container,
  Typography,
  Button,
  Stack,
  Divider,
  MenuItem,
  Select
} from '@mui/material';

const categories = [
  'Tops & Sweaters',
  'Jackets & Coats',
  'Pants',
  'Jeans',
  'Shoes & Bags',
];

const filters = ['Category', 'Size', 'Color', 'Price', 'Fit'];

export default function ProductsTop() {
  return (
    <Container maxWidth="xl" sx={{ mt: 4 }}>
      
      {/* Page Title */}
      <Typography variant="h4" sx={{ fontWeight: 500, mb: 2 }}>
        Men&apos;s Clothing & Accessories
      </Typography>

      {/* Categories */}
      <Stack direction="row" spacing={3} sx={{ mb: 3 }}>
        {categories.map((item) => (
          <Typography
            key={item}
            sx={{
              cursor: 'pointer',
              fontSize: 14,
              color: '#0F1A2C',
              '&:hover': { textDecoration: 'underline' }
            }}
          >
            {item}
          </Typography>
        ))}
      </Stack>

      <Divider sx={{ mb: 3 }} />

      {/* Filters + Sort */}
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: 2,
        }}
      >
        {/* Left Filters */}
        <Stack direction="row" spacing={1} flexWrap="wrap">
          {filters.map((filter) => (
            <Button
              key={filter}
              variant="outlined"
              size="small"
              sx={{
                borderRadius: '20px',
                textTransform: 'none',
                fontSize: 13,
                color: '#0F1A2C',
                borderColor: '#D1D5DB',
              }}
            >
              {filter}
            </Button>
          ))}

          <Button
            variant="outlined"
            size="small"
            sx={{
              borderRadius: '20px',
              textTransform: 'none',
              fontSize: 13,
              color: '#0F1A2C',
              borderColor: '#D1D5DB',
            }}
          >
            All Filters
          </Button>
        </Stack>

        {/* Right Sort */}
        <Stack direction="row" spacing={2} alignItems="center">
          <Typography fontSize={13} color="text.secondary">
            1,606 Items
          </Typography>

          <Select
            size="small"
            defaultValue="recommended"
            sx={{
              fontSize: 13,
              borderRadius: '20px',
            }}
          >
            <MenuItem value="recommended">Recommended</MenuItem>
            <MenuItem value="newest">Newest</MenuItem>
            <MenuItem value="priceLow">Price: Low to High</MenuItem>
            <MenuItem value="priceHigh">Price: High to Low</MenuItem>
          </Select>
        </Stack>
      </Box>

    </Container>
  );
}
