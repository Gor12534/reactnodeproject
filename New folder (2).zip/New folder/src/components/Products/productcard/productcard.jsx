import {
  Card,
  CardContent,
  Typography,
  Box,
  Rating
} from '@mui/material';

export default function ProductCard({ product }) {
  return (
    <Card
      elevation={0}
      sx={{
        cursor: 'pointer',
        '&:hover img': { transform: 'scale(1.05)' },
      }}
    >
      {/* Image */}
      <Box sx={{ overflow: 'hidden' }}>
        <img
          src={product.image}
          alt={product.title}
          style={{
            width: '100%',
            transition: '0.3s ease',
          }}
        />
      </Box>

      <CardContent sx={{ px: 0 }}>
        {/* Title */}
        <Typography fontSize={14} fontWeight={500}>
          {product.title}
        </Typography>

        {/* Price */}
        <Box sx={{ display: 'flex', gap: 1, mt: 0.5 }}>
          {product.oldPrice && (
            <Typography
              fontSize={13}
              sx={{ textDecoration: 'line-through', color: '#6B7280' }}
            >
              ${product.oldPrice}
            </Typography>
          )}

          <Typography fontSize={13} fontWeight={600}>
            ${product.price}
          </Typography>

          {product.discount && (
            <Typography fontSize={13} color="error">
              {product.discount}% off
            </Typography>
          )}
        </Box>

        {/* Colors */}
        <Box sx={{ display: 'flex', gap: 0.7, mt: 1 }}>
          {product.colors.map((color, index) => (
            <Box
              key={index}
              sx={{
                width: 14,
                height: 14,
                borderRadius: '50%',
                bgcolor: color,
                border: '1px solid #E5E7EB',
              }}
            />
          ))}
          <Typography fontSize={12} color="text.secondary">
            + More Colors
          </Typography>
        </Box>

        {/* Rating */}
        <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
          <Rating size="small" value={product.rating} readOnly />
          <Typography fontSize={12} color="text.secondary" sx={{ ml: 0.5 }}>
            ({product.reviews})
          </Typography>
        </Box>
      </CardContent>
    </Card>
  );
}
