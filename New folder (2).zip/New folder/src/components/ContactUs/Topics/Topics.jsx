import { useNavigate } from 'react-router-dom';
import { Button, Container, Grid, Typography } from '@mui/material';


export default function Topics() {
  const navigate = useNavigate();
const topics = [
  { name: 'Track Your Order', path: '/track-order' },
  { name: 'Returns', path: '/returns' },
  { name: 'Terms & Conditions', path: '/terms' },
  { name: 'Guides', path: '/size-guide' },
  { name: 'FAQs', path: '/faq' },
];

  return (
    <Container maxWidth="lg" sx={{ py: 6 }}>
      <Typography fontWeight={600} mb={3}>
        SELF-SERVICE
      </Typography>

      <Grid container spacing={2}>
        {topics.map((item) => (
          <Grid item xs={12} sm={6} md={4} key={item.name}>
            <Button
              fullWidth
              variant="outlined"
              onClick={() => navigate(item.path)}   // ✅ navigate programmatically
              sx={{
                py: 3,
                borderRadius: 0,
                textTransform: 'none',
                fontWeight: 500,
              }}
            >
              {item.name}
            </Button>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}
