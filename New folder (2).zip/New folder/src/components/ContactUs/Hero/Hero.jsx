import { Box, Typography, Container } from '@mui/material';

export default function Hero() {
  return (
    <Box sx={{ bgcolor: '#000', color: '#fff', py: 8 }}>
      <Container maxWidth="lg">
        <Typography variant="h3" fontWeight={500}>
          How can we help you?
        </Typography>
      </Container>
    </Box>
  );
}
