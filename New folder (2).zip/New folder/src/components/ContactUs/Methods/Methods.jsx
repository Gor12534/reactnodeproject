import {
  Box,
  Container,
  Grid,
  Typography,
  Stack,
  IconButton,
} from '@mui/material';

import InstagramIcon from '@mui/icons-material/Instagram';
import FacebookIcon from '@mui/icons-material/Facebook';
import TwitterIcon from '@mui/icons-material/Twitter';
import PhoneIcon from '@mui/icons-material/Phone';
import EmailIcon from '@mui/icons-material/Email';

export default function Methods() {
  return (
    <Container maxWidth="lg" sx={{ py: 8 }}>
      <Grid container spacing={6}>

        {/* CHAT */}
        <Grid item xs={12} md={4}>
          <Typography fontWeight={600} mb={2}>
            Chat
          </Typography>

          <Typography fontSize={14} mb={2}>
            You can chat with us on our social platforms
          </Typography>

          <Stack direction="row" spacing={1}>
            <IconButton><InstagramIcon /></IconButton>
            <IconButton><FacebookIcon /></IconButton>
            <IconButton><TwitterIcon /></IconButton>
          </Stack>
        </Grid>

        {/* PHONE */}
        <Grid item xs={12} md={4}>
          <Typography fontWeight={600} mb={2}>
            Phone
          </Typography>

          <Stack direction="row" spacing={1} alignItems="center">
            <PhoneIcon />
            <Typography fontSize={14}>
              +1 (800) 123-4567
            </Typography>
          </Stack>
        </Grid>

        {/* EMAIL */}
        <Grid item xs={12} md={4}>
          <Typography fontWeight={600} mb={2}>
            Email
          </Typography>

          <Stack direction="row" spacing={1} alignItems="center">
            <EmailIcon />
            <Typography fontSize={14}>
              support@yourstore.com
            </Typography>
          </Stack>
        </Grid>

      </Grid>

      {/* SCHEDULE */}
      <Box sx={{ mt: 6, textAlign: 'center' }}>
        <Typography fontSize={13} color="text.secondary">
          Monday – Friday: 9am – 9pm
        </Typography>
        <Typography fontSize={13} color="text.secondary">
          Saturday – Sunday: 9am – 5pm
        </Typography>
      </Box>
    </Container>
  );
}
