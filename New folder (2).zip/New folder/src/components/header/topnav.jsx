import * as React from 'react';
import { Link } from 'react-router-dom';

import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import Menu from '@mui/material/Menu';
import MenuIcon from '@mui/icons-material/Menu';
import Container from '@mui/material/Container';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import Tooltip from '@mui/material/Tooltip';
import MenuItem from '@mui/material/MenuItem';

import SearchIcon from '@mui/icons-material/Search';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import Badge from '@mui/material/Badge';

/* NAV PAGES */
const pages = [
  { label: 'Men', path: '/products?category=men' },
  { label: 'Women', path: '/products?category=women' },
  { label: 'Kids', path: '/products?category=kids' },
  { label: 'Sale', path: '/products?sale=true' },
  { label: 'New', path: '/products?new=true' },
];

/* ACCOUNT MENU */
const settings = [
  { label: 'Profile', path: '/account' },
  { label: 'Login / Sign Up', path: '/login' },
  { label: 'Logout', path: '/' },
];

function TopNav() {
  const [anchorElNav, setAnchorElNav] = React.useState(null);
  const [anchorElUser, setAnchorElUser] = React.useState(null);

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };

  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  return (
    <AppBar position="static" sx={{ backgroundColor: '#FAFAFA', color: 'black' }}>
      <Container maxWidth={false} sx={{ px: 2 }}>
        <Toolbar disableGutters>

          {/* LOGO */}
          <Typography
            variant="h6"
            noWrap
            component={Link}
            to="/"
            sx={{
              fontWeight: 700,
              textDecoration: 'none',
              color: 'black',
            }}
          >
            LOGO
          </Typography>

          {/* MOBILE MENU */}
          <Box sx={{ flexGrow: 1, display: { xs: 'flex', sm: 'none' } }}>
            <IconButton onClick={handleOpenNavMenu}>
              <MenuIcon />
            </IconButton>

            <Menu
              anchorEl={anchorElNav}
              open={Boolean(anchorElNav)}
              onClose={handleCloseNavMenu}
            >
              {pages.map((page) => (
                <MenuItem
                  key={page.label}
                  component={Link}
                  to={page.path}
                  onClick={handleCloseNavMenu}
                >
                  <Typography>{page.label}</Typography>
                </MenuItem>
              ))}
            </Menu>
          </Box>

          {/* DESKTOP MENU */}
          <Box
            sx={{
              flexGrow: 1,
              display: { xs: 'none', sm: 'flex' },
              justifyContent: 'center',
            }}
          >
            {pages.map((page) => (
              <Button
                key={page.label}
                component={Link}
                to={page.path}
                sx={{
                  color: 'black',
                  mx: 1,
                  textDecoration: 'none',
                }}
              >
                {page.label}
              </Button>
            ))}
          </Box>

          {/* RIGHT ICONS */}
          <Box sx={{ display: 'flex', alignItems: 'center', ml: 'auto' }}>

     
            {/* CART */}
            <IconButton component={Link} to="/cart">
              <Badge badgeContent={2} color="error">
                <ShoppingCartIcon />
              </Badge>
            </IconButton>

            {/* ACCOUNT */}
            <Tooltip title="Account">
              <IconButton onClick={handleOpenUserMenu} sx={{ ml: 1 }}>
                <Avatar />
              </IconButton>
            </Tooltip>

            <Menu
              anchorEl={anchorElUser}
              open={Boolean(anchorElUser)}
              onClose={handleCloseUserMenu}
            >
              {settings.map((setting) => (
                <MenuItem
                  key={setting.label}
                  component={Link}
                  to={setting.path}
                  onClick={handleCloseUserMenu}
                >
                  {setting.label}
                </MenuItem>
              ))}
            </Menu>

          </Box>
        </Toolbar>
      </Container>
    </AppBar>
  );
}

export default TopNav;
