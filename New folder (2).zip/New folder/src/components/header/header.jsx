import React from 'react';
import TopNav from './topnav';

export default function Header() {
  return (
    <header>
      <TopNav />
    </header>
  );
}
