import { Box, Typography } from "@mui/material";

export default function Banner() {
  return (
    <Box
      sx={{
        width: "100%",
        backgroundColor: "#7C1C2C", // burgundy accent
        color: "#FFFFFF",
        textAlign: "center",
        py: 1, // vertical padding
      }}
    >
      <Typography
        sx={{
          fontSize: "14px",
          fontWeight: 500,
          letterSpacing: "0.5px",
        }}
      >
        Free standard shipping on orders over $100
      </Typography>
    </Box>
  );
}
