import { Box, List, ListItemButton, Typography } from '@mui/material';
import { NavLink } from 'react-router-dom';

export default function AdminSidebar() {
  return (
    <Box sx={{ width: 240, bgcolor: '#111', color: '#fff', p: 3 }}>
      <Typography fontWeight={700} mb={3}>
        ADMIN
      </Typography>

      <List>
        <ListItemButton component={NavLink} to="/admin/products">
          Products
        </ListItemButton>
        <ListItemButton component={NavLink} to="/admin/orders">
          Orders
        </ListItemButton>
        <ListItemButton component={NavLink} to="/admin/users">
          Users
        </ListItemButton>
      </List>
    </Box>
  );
}
