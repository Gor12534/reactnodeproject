// src/components/CartPage.js
import React from 'react';
import { Container, Grid } from '@mui/material';
import ProductCard from '../components/Cart/ProductCard/ProductCard.jsx';
import OrderSummary from '../components/Cart/OrderSum/OrderSum.jsx';
import img2 from '../assets/images/download.jpg';       

const Cart = () => {
  const cartItems = [
    {
      id: 1,
      name: "Classic Quarter-Zip Sweater",
      color: "Grey Heather",
      size: "M",
      originalPrice: 89.5,
      discountedPrice: 53.7,
      imageUrl: img2,
    },
    {
      id: 2,
      name: "THFlex Knit Straight Jean",
      color: "Mid Blue Wash Denim",
      size: "38W x 32L",
      originalPrice: 99.5,
      discountedPrice: 69.65,
      imageUrl: img2,
    },
  ];

  const subtotal = cartItems.reduce((acc, item) => acc + item.discountedPrice, 0);

  return (
    <Container maxWidth="lg">
      <Grid container spacing={3}>
        {/* Product List */}
        <Grid item xs={8}>
          {cartItems.map((item) => (
            <ProductCard key={item.id} product={item} />
          ))}
        </Grid>

        {/* Order Summary */}
        <Grid item xs={4}>
          <OrderSummary subtotal={subtotal} />
        </Grid>
      </Grid>
    </Container>
  );
};

export default Cart;
