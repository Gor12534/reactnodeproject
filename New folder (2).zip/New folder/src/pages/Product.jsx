import { Container, Grid } from '@mui/material';
import ProductImages from '../components/ProductPage/productImages/productimages.jsx'
import ProductInfo from '../components/ProductPage/ProductInfo/ProductInfo.jsx';

export default function ProductPage() {
  return (
    <Container maxWidth="xl" sx={{ mt: 4 }}>
      <Grid container spacing={6}>
        <Grid item xs={12} md={7}>
          <ProductImages />
        </Grid>

        <Grid item xs={12} md={5}>
          <ProductInfo />
        </Grid>
      </Grid>
     
    </Container>
  );
}
