// src/components/AboutUsPage.js
import React from 'react';
import { Container, Box, Typography } from '@mui/material';
import OurStory from '../components/AboutUs/OurStory/OurStory';
import Sustainability from '../components/AboutUs/Sustainability/Sustainability';
import Careers from '../components/AboutUs/Careers/Careers';
import Press from '../components/AboutUs/Press/Press';

const AboutUs = () => {
  return (
    <Container maxWidth="lg" sx={{ paddingTop: 4 }}>
      <Box sx={{ textAlign: 'center', marginBottom: 6 }}>
        <Typography variant="h3" gutterBottom>
          About Us
        </Typography>
        <Typography variant="body1" color="textSecondary">
          Learn more about our brand, our mission, and what we stand for.
        </Typography>
      </Box>

      {/* Our Story Section */}
      <OurStory />

      {/* Sustainability Section */}
      <Sustainability />

      {/* Careers Section */}
      <Careers />

      {/* Press Section */}
      <Press />
    </Container>
  );
};

export default AboutUs;
