import {
  Container,
  Typography,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
} from '@mui/material';

const sizes = [
  { size: 'S', chest: '90-95', waist: '76-81' },
  { size: 'M', chest: '96-101', waist: '82-87' },
  { size: 'L', chest: '102-107', waist: '88-93' },
  { size: 'XL', chest: '108-113', waist: '94-99' },
];

export default function SizeGuidePage() {
  return (
    <Container maxWidth="md" sx={{ py: 8 }}>
      <Typography variant="h4" mb={4}>
        Size Guide
      </Typography>

      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Size</TableCell>
            <TableCell>Chest (cm)</TableCell>
            <TableCell>Waist (cm)</TableCell>
          </TableRow>
        </TableHead>

        <TableBody>
          {sizes.map((row) => (
            <TableRow key={row.size}>
              <TableCell>{row.size}</TableCell>
              <TableCell>{row.chest}</TableCell>
              <TableCell>{row.waist}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Container>
  );
}
