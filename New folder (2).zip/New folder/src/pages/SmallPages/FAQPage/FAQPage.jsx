import {
  Container,
  Typography,
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

const faqs = [
  ['How long does shipping take?', 'Shipping usually takes 3–7 business days.'],
  ['Can I cancel my order?', 'Orders can be canceled within 24 hours.'],
  ['Do you ship internationally?', 'Yes, we ship worldwide.'],
  ['How do I return an item?', 'You can return items from the returns page.'],
  ['Are refunds available?', 'Yes, refunds are processed within 5 days.'],
  ['How do I track my order?', 'Use the Track Order page.'],
  ['What payment methods are accepted?', 'Credit cards and PayPal.'],
  ['Is my data secure?', 'Yes, we use secure encryption.'],
  ['Can I change my address?', 'Before shipment only.'],
  ['How do I contact support?', 'Via email or social media.'],
];

export default function FAQPage() {
  return (
    <Container maxWidth="md" sx={{ py: 8 }}>
      <Typography variant="h4" mb={4}>
        Frequently Asked Questions
      </Typography>

      {faqs.map(([q, a], index) => (
        <Accordion key={index}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography fontWeight={500}>{q}</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>{a}</Typography>
          </AccordionDetails>
        </Accordion>
      ))}
    </Container>
  );
}
