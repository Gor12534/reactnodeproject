import { Container, Typography, Box } from '@mui/material';

export default function TermsPage() {
  return (
    <Container maxWidth="md" sx={{ py: 8 }}>
      <Typography variant="h4" mb={4}>
        Terms & Conditions
      </Typography>

      <Box mb={3}>
        <Typography fontWeight={600}>1. General</Typography>
        <Typography>
          By using this website, you agree to follow our terms and policies.
        </Typography>
      </Box>

      <Box mb={3}>
        <Typography fontWeight={600}>2. Orders</Typography>
        <Typography>
          Orders may be canceled within 24 hours after placement.
        </Typography>
      </Box>

      <Box mb={3}>
        <Typography fontWeight={600}>3. Returns</Typography>
        <Typography>
          Returned items must be unused and in original condition.
        </Typography>
      </Box>

      <Box mb={3}>
        <Typography fontWeight={600}>4. Privacy</Typography>
        <Typography>
          We respect your privacy and protect your personal data.
        </Typography>
      </Box>

      <Box>
        <Typography fontWeight={600}>5. Changes</Typography>
        <Typography>
          Terms may be updated without prior notice.
        </Typography>
      </Box>
    </Container>
  );
}
