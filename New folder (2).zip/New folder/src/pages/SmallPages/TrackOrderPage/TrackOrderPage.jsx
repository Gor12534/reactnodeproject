import { Box, Container, Typography, TextField, Button } from '@mui/material';
import { useState } from 'react';

export default function TrackOrderPage() {
  const [status, setStatus] = useState('');

  const checkOrder = () => {
    const statuses = ['Delivered', 'On the way', 'Returned'];
    setStatus(statuses[Math.floor(Math.random() * statuses.length)]);
  };

  return (
    <Container maxWidth="sm" sx={{ py: 8 }}>
      <Typography variant="h4" mb={3}>
        Track Your Order
      </Typography>

      <TextField
        fullWidth
        label="Enter Order Number"
        variant="outlined"
        sx={{ mb: 2 }}
      />

      <Button variant="contained" fullWidth onClick={checkOrder}>
        Check Status
      </Button>

      {status && (
        <Box mt={4}>
          <Typography fontWeight={600}>
            Order Status:
          </Typography>
          <Typography color="primary">
            {status}
          </Typography>
        </Box>
      )}
    </Container>
  );
}
