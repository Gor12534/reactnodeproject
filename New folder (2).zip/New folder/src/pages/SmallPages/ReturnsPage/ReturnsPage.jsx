import {
  Container,
  Typography,
  List,
  ListItem,
  ListItemText,
  Button,
} from '@mui/material';

const orders = [
  { id: 'ORD-1001', status: 'Completed' },
  { id: 'ORD-1002', status: 'Completed' },
  { id: 'ORD-1003', status: 'Completed' },
];

export default function ReturnsPage() {
  return (
    <Container maxWidth="md" sx={{ py: 8 }}>
      <Typography variant="h4" mb={3}>
        Returns
      </Typography>

      <List>
        {orders.map((order) => (
          <ListItem
            key={order.id}
            secondaryAction={
              <Button variant="outlined">Return</Button>
            }
          >
            <ListItemText
              primary={`Order ${order.id}`}
              secondary={`Status: ${order.status}`}
            />
          </ListItem>
        ))}
      </List>
    </Container>
  );
}
