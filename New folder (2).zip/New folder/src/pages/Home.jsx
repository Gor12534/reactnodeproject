import Hero from '../components/Home/hero/Hero.jsx';
import Hero2 from '../components/Home/hero2/Hero2.jsx';
import JoinBanner from '../components/Home/joinbanner/joinbanner.jsx';
import FeaturedCards from '../components/Home/cards/cards.jsx';
export default function Home() {
  return (
    <>
      <Hero />
        <Hero2 />
      <p>Hello! This is the placeholder page.</p>
      <p>Hello! This is the placeholder page.</p>
      <p>Hello! This is the placeholder page.</p>
       <p>Hello! This is the placeholder page.</p>

        <p>Hello! This is the placeholder page.</p>
         <p>Hello! This is the placeholder page.</p>
          <p>Hello! This is the placeholder page.</p>

           <p>Hello! This is the placeholder page.</p>

           <FeaturedCards /> 
      <JoinBanner />
    </>
  );
}
