import Hero from '../components/ContactUs/Hero/Hero';
import Topics from '../components/ContactUs/Topics/Topics';
import Methods from '../components/ContactUs/Methods/Methods';

export default function ContactUs() {
  return (
    <>
      < Hero />
      <Topics />
      <Methods />
    </>
  );
}
