import ProductsTop from "../components/Products/prodtop/prodtop";
import ProductsGrid from "../components/Products/productsgrid/productsgrid"; 
export default function Products() {
  return (
    <>
      <ProductsTop />
      <ProductsGrid />
    </>
  );
}
