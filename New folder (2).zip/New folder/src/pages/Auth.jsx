import { useState } from 'react';
import { Container } from '@mui/material';

import AuthTabs from '../components/Auth/Tabs/Tabs';
import LoginForm from '../components/Auth/LoginForm/LoginForm';
import RegisterForm from '../components/Auth/RegisterForm/RegisterForm';

export default function AuthPage() {
  const [mode, setMode] = useState('login');

  return (
    <Container maxWidth="sm" sx={{ py: 8 }}>
      <AuthTabs mode={mode} setMode={setMode} />

      {mode === 'login' ? <LoginForm /> : <RegisterForm />}
    </Container>
  );
}
