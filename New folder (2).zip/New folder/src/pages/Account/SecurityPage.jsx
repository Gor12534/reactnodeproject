import { Box, Button, TextField, Typography } from '@mui/material';

export default function SecurityPage() {
  return (
    <Box>
      <Typography variant="h5" fontWeight={600} mb={3}>
        Change Password
      </Typography>

      <TextField fullWidth label="Current Password" type="password" margin="normal" />
      <TextField fullWidth label="New Password" type="password" margin="normal" />
      <TextField fullWidth label="Confirm New Password" type="password" margin="normal" />

      <Button variant="contained" sx={{ mt: 3 }}>
        Update Password
      </Button>
    </Box>
  );
}
