import { Box, Container } from '@mui/material';
import { Outlet } from 'react-router-dom';
import AccountSidebar from '../../components/Account/AccountSidebar/AccountSidebar';

export default function AccountLayout() {
  return (
    <Container maxWidth="lg" sx={{ py: 6 }}>
      <Box sx={{ display: 'flex', gap: 4 }}>
        <AccountSidebar />
        <Box sx={{ flexGrow: 1 }}>
          <Outlet />
        </Box>
      </Box>
    </Container>
  );
}
