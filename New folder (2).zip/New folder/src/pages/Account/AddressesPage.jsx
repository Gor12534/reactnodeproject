import { Box, Typography, Button } from '@mui/material';

export default function AddressesPage() {
  return (
    <Box>
      <Typography variant="h5" fontWeight={600} mb={3}>
        Addresses
      </Typography>

      <Box sx={{ border: '1px solid #ddd', p: 3, mb: 2 }}>
        <Typography>Yerevan, Armenia</Typography>
        <Typography variant="body2">Abovyan street</Typography>
      </Box>

      <Button variant="outlined">Add New Address</Button>
    </Box>
  );
}
