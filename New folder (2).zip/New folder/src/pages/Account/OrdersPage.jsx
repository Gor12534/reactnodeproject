import { Box, Typography, Button } from '@mui/material';

export default function OrdersPage() {
  return (
    <Box>
      <Typography variant="h5" fontWeight={600} mb={3}>
        My Orders
      </Typography>

      <Box sx={{ border: '1px solid #ddd', p: 3, mb: 2 }}>
        <Typography>Order #12345</Typography>
        <Typography variant="body2">Status: Delivered</Typography>

        <Box sx={{ mt: 2 }}>
          <Button size="small">Return</Button>
          <Button size="small">Cancel</Button>
        </Box>
      </Box>
    </Box>
  );
}
