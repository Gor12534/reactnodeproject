import { Box, Button, TextField, Typography, Avatar } from '@mui/material';

export default function ProfilePage() {
  return (
    <Box>
      <Typography variant="h5" fontWeight={600} mb={3}>
        Profile Information
      </Typography>

      <Box sx={{ display: 'flex', alignItems: 'center', gap: 3, mb: 4 }}>
        <Avatar sx={{ width: 80, height: 80 }} />
        <Button variant="outlined">Change Avatar</Button>
      </Box>

      <TextField fullWidth label="Full Name" margin="normal" />
      <TextField fullWidth label="Email" margin="normal" />

      <Button
        variant="contained"
        sx={{ mt: 3, borderRadius: 0 }}
      >
        Save Changes
      </Button>
    </Box>
  );
}
