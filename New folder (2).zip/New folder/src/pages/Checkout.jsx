// src/components/CheckoutPage.js
import React from 'react';
import { Container, Grid, Box,Paper,Typography,Stack } from '@mui/material';
import ShippingTo from '../components/Checkout/ShippingTo/ShippngTo.jsx';
import ContactInfo from '../components/Checkout/ContactInfo/ContactInfo.jsx';
import OrderSummary from '../components/Checkout/OrderSummary/OrderSummary.jsx';
import ShoppingBag from '../components/Checkout/ShoppingBag/ShoppingBag.jsx';
import img2 from '../assets/images/download.jpg';  
// src/components/CheckoutPage.js

// import './aa.css';

const CheckoutPage = () => {
  const cartItems = [
    {
      id: 1,
      name: "THaaFlex Knit Straight Jean",
      color: "Mid Blue Wash Denim",
      size: "38W x 32L",
      discountedPrice: 69.65,
      quantity: 1,
      imageUrl: img2,
    },
    {
      id: 2,
      name: "Classic Quarter-Zip Sweater",
      color: "Grey Heather",
      size: "M",
      discountedPrice: 53.7,
      quantity: 1,
      imageUrl: img2,
    },
  ];

  const subtotal = cartItems.reduce((acc, item) => acc + item.discountedPrice * item.quantity, 0);

const TestBox = ({ title, color }) => (
  <Paper sx={{ p: 5, bgcolor: color, color: 'white' }}>
    <Typography variant="h5">{title}</Typography>
  </Paper>
);

  return (
  <Box sx={{ width: '100%', maxWidth: '1200px', mx: 'auto', mt: 5,bgcolor: '#f9f9f9', minHeight: '95vh', py: 5 }} >
    <Box sx={{ 
      display: 'flex', 
      flexDirection: { xs: 'column', md: 'row' }, // Stack on mobile, row on desktop
      gap: 4,
      alignItems: 'flex-start' 
    }}>
      
      {/* LEFT SIDE - Forced to 60% */}
      <Box sx={{ flex: '0 0 60%', minWidth: 0 }}>
        <Paper elevation={0} sx={{ p: 3, border: '1px solid #eee' }}>
          <ShippingTo />
            
        </Paper>
        <Paper elevation={0} sx={{ p: 3, border: '1px solid #eee' }}> 

          <ContactInfo />
        </Paper>
      </Box>

      {/* RIGHT SIDE - Forced to 40% */}
      <Box sx={{ flex: '1 1 auto', minWidth: 0 }}>
        <Stack spacing={3}>
          <OrderSummary subtotal={subtotal} />
          <ShoppingBag cartItems={cartItems} />
        </Stack>
      </Box>

    </Box>
  </Box>
  );
};

export default CheckoutPage;



