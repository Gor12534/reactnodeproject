import { Box, Button, Container, TextField, Typography } from '@mui/material';

export default function AdminLogin() {
  return (
    <Container maxWidth="xs" sx={{ py: 10 }}>
      <Typography variant="h5" fontWeight={600} mb={3} textAlign="center">
        Admin Login
      </Typography>

      <TextField fullWidth label="Email" margin="normal" />
      <TextField fullWidth label="Password" type="password" margin="normal" />

      <Button fullWidth variant="contained" sx={{ mt: 3 }}>
        Login
      </Button>
    </Container>
  );
}
