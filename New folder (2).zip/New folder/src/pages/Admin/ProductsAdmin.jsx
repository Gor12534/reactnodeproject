import { Box, Button, Typography } from '@mui/material';

export default function ProductsAdmin() {
  return (
    <Box>
      <Typography variant="h5" fontWeight={600} mb={3}>
        Products
      </Typography>

      <Button variant="contained">Add Product</Button>

      <Box sx={{ mt: 3, border: '1px solid #ddd', p: 2 }}>
        Product Name – Sizes: S, M, L
        <Box>
          <Button size="small">Edit</Button>
          <Button size="small" color="error">Delete</Button>
        </Box>
      </Box>
    </Box>
  );
}
