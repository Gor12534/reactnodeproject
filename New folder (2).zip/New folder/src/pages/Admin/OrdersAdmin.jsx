import { Box, Typography } from '@mui/material';

export default function OrdersAdmin() {
  return (
    <Box>
      <Typography variant="h5" fontWeight={600} mb={3}>
        Orders
      </Typography>

      <Box sx={{ border: '1px solid #ddd', p: 2 }}>
        Order #12345 – user@email.com – Pending
      </Box>
    </Box>
  );
}
