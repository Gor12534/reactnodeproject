import { Box, Button, Typography } from '@mui/material';

export default function UsersAdmin() {
  return (
    <Box>
      <Typography variant="h5" fontWeight={600} mb={3}>
        Users
      </Typography>

      <Box sx={{ border: '1px solid #ddd', p: 2, mb: 2 }}>
        user@email.com
        <Box>
          <Button size="small">Make Admin</Button>
          <Button size="small" color="error">Block</Button>
        </Box>
      </Box>
    </Box>
  );
}
