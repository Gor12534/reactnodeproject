
import Header from '../components/header/header';
import Footer from '../components/footer/Footer';
import Banner from '../components/banner/Banner';
export default function MainLayout({ children }) {
  return (
    <div>
      <Header />
      <Banner />
      <main >
        {children}
      </main>
      <Footer />
    </div>
  );
}



///#FAFAFA    white 
// #0F1A2C  dark blue
/// #6B6B6B gray
//  #9E1B32 red
// #7C1C2C dark red wine



