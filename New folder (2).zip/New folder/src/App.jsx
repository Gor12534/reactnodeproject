// src/App.jsx
import React from 'react';
import { Routes, Route } from 'react-router-dom';

import MainLayout from './layouts/MainLayout';

/* Main Pages */
import Home from './pages/Home';
import Products from './pages/Products';
import ProductPage from './pages/Product';
import Cart from './pages/Cart';
import CheckoutPage from './pages/Checkout';

/* Info Pages */
import AboutUs from './pages/AboutUs';
import ContactUs from './pages/ContactUs';

/* Small Pages */
import TrackOrderPage from './pages/SmallPages/TrackOrderPage/TrackOrderPage';
import ReturnsPage from './pages/SmallPages/ReturnsPage/ReturnsPage';
import FAQPage from './pages/SmallPages/FAQPage/FAQPage';
import TermsPage from './pages/SmallPages/TermsPage/TermsPage';
import SizeGuidePage from './pages/SmallPages/SizeGuidePage/SizeGuidePage';

import AuthPage from './pages/Auth';
import AccountLayout from './pages/Account/AccountLayout';
import ProfilePage from './pages/Account/ProfilePage';
import OrdersPage from './pages/Account/OrdersPage';
import AddressesPage from './pages/Account/AddressesPage';
import SecurityPage from './pages/Account/SecurityPage';

import AdminLogin from './pages/Admin/AdminLogin';
import AdminLayout from './pages/Admin/AdminLayout';
import ProductsAdmin from './pages/Admin/ProductsAdmin';
import OrdersAdmin from './pages/Admin/OrdersAdmin';
import UsersAdmin from './pages/Admin/UsersAdmin';

function App() {
  return (
    <MainLayout>
      <Routes>
        {/* Home */}
        <Route path="/" element={<Home />} />

        {/* Products */}
        <Route path="/products" element={<Products />} />
        <Route path="/product/:id" element={<ProductPage />} />

        {/* Cart & Checkout */}
        <Route path="/cart" element={<Cart />} />
        <Route path="/checkout" element={<CheckoutPage />} />

        {/* Info */}
        <Route path="/about" element={<AboutUs />} />
        <Route path="/contact" element={<ContactUs />} />

        {/* Support Pages */}
        <Route path="/track-order" element={<TrackOrderPage />} />
        <Route path="/returns" element={<ReturnsPage />} />
        <Route path="/faq" element={<FAQPage />} />
        <Route path="/terms" element={<TermsPage />} />
        <Route path="/size-guide" element={<SizeGuidePage />} />

        {/* login */}

        <Route path="/auth" element={<AuthPage />} />



        <Route path="/account" element={<AccountLayout />}>
  <Route path="profile" element={<ProfilePage />} />
  <Route path="orders" element={<OrdersPage />} />
  <Route path="addresses" element={<AddressesPage />} />
  <Route path="security" element={<SecurityPage />} />
</Route>



        <Route path="/admin/login" element={<AdminLogin />} />

<Route path="/admin" element={<AdminLayout />}>
  <Route path="products" element={<ProductsAdmin />} />
  <Route path="orders" element={<OrdersAdmin />} />
  <Route path="users" element={<UsersAdmin />} />
</Route>

      </Routes>
    </MainLayout>
  );
}

export default App;
